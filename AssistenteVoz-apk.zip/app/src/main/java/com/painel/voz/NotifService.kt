package com.painel.voz

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    companion object {
        private val items = ArrayList<String>()
        @Volatile private var instance: NotifService? = null
        fun recent(): List<String> = synchronized(items) { items.toList() }
        fun clearAll() {
            synchronized(items) { items.clear() }
            instance?.cancelAllNotifications()
        }
    }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val body = listOf(title, text).filter { it.isNotEmpty() }.joinToString(" — ")
        if (body.isEmpty()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName }
        synchronized(items) {
            items.add(0, "$app: $body")
            while (items.size > 20) items.removeAt(items.size - 1)
        }
    }
}
