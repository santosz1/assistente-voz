package com.painel.voz

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var wanted = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }

    private fun js(code: String) { main.post { web.evaluateJavascript(code, null) } }
    private fun q(s: String) = JSONObject.quote(s)
    private fun norm(s: String) =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").trim()

    /* ---------- Voz (reconhecimento nativo, sem resposta falada) ---------- */
    private fun startMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("appError('Reconhecimento de voz indisponível neste aparelho.')"); return
        }
        wanted = true
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        }
        js("appMic(true)")
        listen()
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        recognizer?.startListening(i)
    }

    private fun stopMic() { wanted = false; recognizer?.cancel(); js("appMic(false)") }
    private fun again(delay: Long) { if (wanted) main.postDelayed({ if (wanted) listen() }, delay) }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) startMic()
        else js("appError('Permissão do microfone negada.')")
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: Bundle?) {
            r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                ?.let { js("appHeard(${q(it)}, true)") }
            again(250)
        }
        override fun onPartialResults(r: Bundle?) {
            r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                ?.let { js("appHeard(${q(it)}, false)") }
        }
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                wanted = false; js("appMic(false)"); js("appError('Permissão do microfone negada.')")
            } else again(600)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    /* ---------- Ponte JavaScript <-> Android ---------- */
    inner class Bridge {
        @JavascriptInterface fun toggleMic() { main.post { if (wanted) stopMic() else startMic() } }

        @JavascriptInterface fun notifs(): String = JSONArray(NotifService.recent()).toString()

        @JavascriptInterface fun run(cmd: String, arg: String): String = when (cmd) {
            "app" -> {
                val pm = packageManager
                val want = norm(arg)
                val apps = pm.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == want }
                    ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(want) }
                val launch = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                if (hit == null || launch == null) "Não encontrei o app \"$arg\"."
                else { main.post { startActivity(launch) }; "Abrindo ${hit.loadLabel(pm)}." }
            }
            "wifi" -> {
                main.post { startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
                "Abrindo o painel de Wi-Fi."
            }
            "lanterna" -> try {
                val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                cm.setTorchMode(id, arg == "on")
                if (arg == "on") "Lanterna ligada." else "Lanterna desligada."
            } catch (e: Exception) { "Não consegui acessar a lanterna." }
            "volume" -> {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    if (arg == "up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI)
                "Volume ajustado."
            }
            "discar" -> {
                main.post { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$arg"))) }
                "Abrindo o discador para $arg."
            }
            "permitir_notificacoes" -> {
                main.post { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                "Ative o acesso a notificações para o Painel Voz."
            }
            "limpar_notificacoes" -> { NotifService.clearAll(); "Notificações limpas." }
            else -> "Comando desconhecido."
        }
    }
}
