# Assistente de Voz (Android)

## Como rodar
1. Instale o **Android Studio** e abra esta pasta (`AssistenteVoz`).
2. Espere o "Sync" do Gradle terminar (precisa de internet na primeira vez).
3. Ative a **depuração USB** no celular, conecte no PC e clique em ▶ Run.

## Primeiro uso (nessa ordem)
1. Toque em **Falar** e permita o microfone.
2. **Liberar acesso às notificações** → ative "Assistente de Voz".
3. **Liberar controle do celular** → ative "Assistente de Voz".
4. (Opcional) Cole sua **chave da API da Anthropic** e toque em Salvar, para responder qualquer pergunta.

## Usar pelo botão do fone Bluetooth
1. Ligue **"Ativar pelo botão play/pause do fone"** e permita o que o Android pedir
   (microfone, notificações, Bluetooth). Vai aparecer uma notificação fixa: ela precisa ficar lá.
2. Com o fone conectado, **aperte o botão play/pause**: você ouve um "bip" e pode falar.
3. Aperte de novo para **cancelar** a escuta ou **calar** a resposta.
4. "Usar o microfone do fone" ligado → ele capta sua voz pelo fone (mais perto da boca).
   Desligado → usa o microfone do celular.

### Pontos de atenção
- Enquanto o serviço estiver ligado, o botão do fone **não pausa mais a música**.
  Para voltar ao normal, desligue a chave.
- Se você **abrir Spotify, YouTube etc.**, o Android pode mandar o botão para eles.
  Abra o Assistente de Voz de novo (ou desligue e ligue a chave) para recuperar o botão.
- O app toca um áudio **silencioso** em segundo plano só para o Android mandar o botão para ele.
  Isso pode gastar um pouco mais de bateria do celular e do fone.
- Se o celular matar o app (economia de bateria), abra o app de novo. Em Configurações → Bateria,
  deixe o Assistente de Voz como "Sem restrições".
- Alguns fones têm botões diferentes (play/pause, atender/desligar). O app reconhece os dois.

## Voz estilo Jarvis
Na tela principal, seção **Voz do assistente**:
- **Voz grave e calma (estilo Jarvis)**: baixa o tom e a velocidade da voz nativa e escolhe
  automaticamente a melhor voz em português instalada no aparelho.
- **Escolher voz do aparelho**: lista as vozes em português do Android; toque numa para ouvir.
  Dica: em Configurações do Android → Idioma → Saída de texto para voz, dá para baixar mais vozes.
- **Como devo te chamar?**: o assistente usa esse tratamento nas respostas da IA (ex.: "senhor").
- **ElevenLabs (opcional)**: cole a chave da API e o ID de uma voz da sua conta em elevenlabs.io.
  Com os dois preenchidos, o app usa a voz neural (mais realista). Se faltar internet ou a chave
  estiver errada, ele volta sozinho para a voz nativa. O uso é cobrado/limitado pelo plano da ElevenLabs.
- **Testar voz**: toque para ouvir uma frase de teste depois de salvar.

## O que ele faz por voz
- "que horas são", "que dia é hoje", "qual a bateria"
- "liga a lanterna" / "apaga a lanterna"
- "aumenta o volume" / "diminui o volume"
- "abrir WhatsApp" (qualquer app instalado)
- "timer de 5 minutos"
- "ligar para 11 9 9999 9999" (abre o discador)
- "voltar", "tela inicial", "recentes", "abrir notificações"
- "parar" (silencia a voz)
- Qualquer outra pergunta vai para a IA (precisa da chave e de internet)
- Notificações que chegam são lidas em voz alta (dá para desligar no app)

## Limites desta versão
- Ainda não tem palavra de ativação tipo "Ok assistente": só o botão do fone ou o botão da tela.
- Não lê nome de contato para ligar, só números.
- Com a tela bloqueada, alguns comandos (abrir app, lanterna) podem ser barrados pelo Android.
- A chave da API fica guardada no aparelho, sem criptografia: use só no seu celular.

## Sem Android Studio: compilar na nuvem (GitHub)
1. Crie um repositório no github.com e envie o conteúdo desta pasta.
2. Garanta que existe o arquivo `.github/workflows/build.yml` (já vem neste projeto).
3. Aba **Actions** → abra a execução "Build APK" → em **Artifacts** baixe `AssistenteVoz-apk`.
4. Extraia o zip, envie o `app-debug.apk` para o celular e instale.
