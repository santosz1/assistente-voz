package com.exemplo.assistentevoz

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Lê em voz alta as notificações que chegam no celular. */
class NotificationReaderService : NotificationListenerService() {

    private val lastSpoken = HashMap<String, String>()

    override fun onCreate() {
        super.onCreate()
        Speaker.init(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        if (!Prefs(this).readNotifications) return
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return // ignora música, navegação, chamadas em andamento etc.

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        // Evita repetir a mesma notificação quando o app só a atualiza.
        val signature = "$title|$text"
        if (lastSpoken[sbn.key] == signature) return
        lastSpoken[sbn.key] = signature
        if (lastSpoken.size > 200) lastSpoken.clear()

        val appName = try {
            val info = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            sbn.packageName
        }

        Speaker.speak("Notificação do $appName. $title. $text")
    }
}
