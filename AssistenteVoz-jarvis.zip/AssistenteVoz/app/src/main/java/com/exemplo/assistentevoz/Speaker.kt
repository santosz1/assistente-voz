package com.exemplo.assistentevoz

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * A "voz" do assistente.
 *
 * Dois modos:
 *  1) Voz nativa do Android (padrão, grátis, offline), com ajuste "estilo Jarvis":
 *     tom mais grave, fala mais calma e escolha automática de uma voz masculina/de melhor qualidade.
 *  2) Voz neural da ElevenLabs (opcional): se houver chave e ID de voz salvos, o texto é
 *     transformado em áudio MP3 na nuvem e tocado. Se falhar (sem internet, chave errada),
 *     cai automaticamente para a voz nativa.
 */
object Speaker {
    private const val TAG = "Speaker"

    // Ajustes do modo "Jarvis" na voz nativa.
    private const val JARVIS_PITCH = 0.80f
    private const val JARVIS_RATE = 0.95f

    // Modelo da ElevenLabs: "eleven_flash_v2_5" é o mais rápido (bom para assistente de voz).
    // Para mais qualidade (e um pouco mais de demora) troque por "eleven_multilingual_v2".
    private const val ELEVEN_MODEL = "eleven_flash_v2_5"

    private var appCtx: Context? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayDeque<String>()

    private val main = Handler(Looper.getMainLooper())
    private val cloudQueue = ArrayDeque<String>()
    private var cloudBusy = false
    private var generation = 0 // sobe a cada stop(), para descartar respostas atrasadas da nuvem
    private var player: MediaPlayer? = null
    private var currentFile: File? = null

    @Synchronized
    fun init(context: Context) {
        if (tts != null) return
        val app = context.applicationContext
        appCtx = app
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                synchronized(this) {
                    tts?.setLanguage(Locale("pt", "BR"))
                    applyNativeVoice()
                    ready = true
                    while (pending.isNotEmpty()) {
                        sayNative(pending.removeFirst())
                    }
                }
            }
        }
    }

    /** Reaplica as configurações de voz (chame depois de mudar as preferências). */
    @Synchronized
    fun reload() {
        if (ready) applyNativeVoice()
    }

    /** Vozes em português instaladas no aparelho (vazio se o motor ainda não iniciou). */
    @Synchronized
    fun portugueseVoices(): List<Voice> {
        if (!ready) return emptyList()
        return try {
            tts?.voices?.filter { it.locale.language == "pt" }?.sortedBy { it.name } ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun speak(text: String) {
        if (text.isBlank()) return
        if (cloudEnabled()) {
            cloudQueue.addLast(text)
            pumpCloud()
        } else {
            speakNative(text)
        }
    }

    @Synchronized
    fun stop() {
        pending.clear()
        cloudQueue.clear()
        generation++
        cloudBusy = false
        player?.let {
            try {
                it.stop()
            } catch (e: Exception) {
                // ignora
            }
            try {
                it.release()
            } catch (e: Exception) {
                // ignora
            }
        }
        player = null
        currentFile?.delete()
        currentFile = null
        tts?.stop()
    }

    @Synchronized
    fun isSpeaking(): Boolean =
        tts?.isSpeaking == true || cloudBusy || cloudQueue.isNotEmpty()

    // ---------- Voz nativa ----------

    private fun speakNative(text: String) {
        if (!ready) {
            pending.addLast(text)
            return
        }
        sayNative(text)
    }

    private fun sayNative(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, System.nanoTime().toString())
    }

    private fun applyNativeVoice() {
        val t = tts ?: return
        val ctx = appCtx ?: return
        val prefs = Prefs(ctx)
        val jarvis = prefs.jarvisVoice

        t.setPitch(if (jarvis) JARVIS_PITCH else 1.0f)
        t.setSpeechRate(if (jarvis) JARVIS_RATE else 1.0f)

        val voices: List<Voice> = try {
            t.voices?.filter { it.locale.language == "pt" } ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
        val chosen = voices.firstOrNull { it.name == prefs.voiceName }
            ?: if (jarvis) pickBestVoice(voices) else null
        if (chosen != null) t.setVoice(chosen)
    }

    /** Prefere pt-BR, voz que pareça masculina, maior qualidade e, por fim, as que funcionam offline. */
    private fun pickBestVoice(voices: List<Voice>): Voice? {
        val br = voices.filter { it.locale.country.equals("BR", ignoreCase = true) }
            .ifEmpty { voices }
        return br.sortedWith(
            compareByDescending<Voice> { looksMale(it) }
                .thenByDescending { it.quality }
                .thenBy { it.isNetworkConnectionRequired }
        ).firstOrNull()
    }

    private fun looksMale(v: Voice): Boolean {
        val n = v.name.lowercase()
        return n.contains("male") && !n.contains("female")
    }

    // ---------- Voz neural (ElevenLabs) ----------

    private fun cloudEnabled(): Boolean {
        val ctx = appCtx ?: return false
        val p = Prefs(ctx)
        return p.elevenKey.isNotBlank() && p.elevenVoiceId.isNotBlank()
    }

    /** Pede o próximo texto da fila à nuvem (um de cada vez, para manter a ordem). */
    private fun pumpCloud() {
        if (cloudBusy || cloudQueue.isEmpty()) return
        val ctx = appCtx ?: return
        val text = cloudQueue.removeFirst()
        val gen = generation
        val p = Prefs(ctx)
        val key = p.elevenKey
        val voiceId = p.elevenVoiceId
        cloudBusy = true
        Thread {
            val file = try {
                fetchAudio(ctx, key, voiceId, text)
            } catch (e: Exception) {
                Log.w(TAG, "Falha na voz da nuvem: ${e.message}")
                null
            }
            main.post { onCloudAudio(file, text, gen) }
        }.start()
    }

    @Synchronized
    private fun onCloudAudio(file: File?, text: String, gen: Int) {
        if (gen != generation) {
            file?.delete()
            return
        }
        if (file == null) {
            cloudBusy = false
            speakNative(text) // plano B: voz nativa
            pumpCloud()
            return
        }
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(file.absolutePath)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { finishPlayback(mp, file, gen) }
            mp.setOnErrorListener { _, _, _ ->
                finishPlayback(mp, file, gen)
                true
            }
            player = mp
            currentFile = file
            mp.prepareAsync()
        } catch (e: Exception) {
            Log.w(TAG, "Falha ao tocar áudio: ${e.message}")
            file.delete()
            player = null
            currentFile = null
            cloudBusy = false
            speakNative(text)
            pumpCloud()
        }
    }

    @Synchronized
    private fun finishPlayback(mp: MediaPlayer, file: File, gen: Int) {
        try {
            mp.release()
        } catch (e: Exception) {
            // ignora
        }
        file.delete()
        if (gen != generation) return // stop() já limpou tudo
        player = null
        currentFile = null
        cloudBusy = false
        pumpCloud()
    }

    /** Baixa o áudio (MP3) da ElevenLabs para um arquivo temporário. Roda fora da thread principal. */
    private fun fetchAudio(ctx: Context, key: String, voiceId: String, text: String): File? {
        val url = URL(
            "https://api.elevenlabs.io/v1/text-to-speech/${voiceId.trim()}?output_format=mp3_44100_128"
        )
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = 20000
            conn.doOutput = true
            conn.setRequestProperty("xi-api-key", key.trim())
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "audio/mpeg")

            val body = JSONObject()
                .put("text", text)
                .put("model_id", ELEVEN_MODEL)
                .put(
                    "voice_settings",
                    JSONObject().put("stability", 0.55).put("similarity_boost", 0.8)
                )
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code !in 200..299) {
                Log.w(TAG, "ElevenLabs respondeu com erro $code")
                return null
            }
            val file = File.createTempFile("voz_", ".mp3", ctx.cacheDir)
            conn.inputStream.use { input -> file.outputStream().use { out -> input.copyTo(out) } }
            if (file.length() == 0L) {
                file.delete()
                return null
            }
            return file
        } finally {
            conn.disconnect()
        }
    }
}
