package com.exemplo.assistentevoz

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Faz uma escuta por voz, sem tela: toca um "bip" quando pode falar,
 * entende o comando, executa e responde em voz alta.
 */
class VoiceListener(
    private val ctx: Context,
    private val commands: CommandHandler
) {
    private val main = Handler(Looper.getMainLooper())
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var recognizer: SpeechRecognizer? = null
    private var usingBluetoothMic = false

    var listening = false
        private set

    fun start(useBluetoothMic: Boolean) {
        if (listening) return
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Speaker.speak("Preciso da permissão do microfone. Abra o aplicativo e permita.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            Speaker.speak("O reconhecimento de voz não está disponível.")
            return
        }
        listening = true
        Speaker.stop()

        usingBluetoothMic = useBluetoothMic && routeToBluetoothMic()
        // O microfone do fone leva um instante para conectar.
        main.postDelayed({ if (listening) begin() }, if (usingBluetoothMic) 900L else 0L)
    }

    fun cancel() {
        if (!listening) return
        recognizer?.cancel()
        finish()
    }

    private fun begin() {
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { beep() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                finish()
                val noSpeech = error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                Speaker.speak(if (noSpeech) "Não ouvi nada." else "Não consegui ouvir.")
            }

            override fun onResults(results: Bundle?) {
                finish()
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                commands.handle(text) { answer -> Speaker.speak(answer) }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
        }
        r.startListening(intent)
    }

    private fun finish() {
        listening = false
        releaseBluetoothMic()
        val old = recognizer
        recognizer = null
        // Destrói depois, para não mexer no reconhecedor dentro do próprio callback.
        main.post { old?.destroy() }
    }

    private fun beep() {
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        } catch (e: Exception) {
            // sem bip, segue normalmente
        }
    }

    // ---------- Microfone do fone Bluetooth ----------

    private fun routeToBluetoothMic(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    return false
                }
                val device = audio.availableCommunicationDevices.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                } ?: return false
                audio.setCommunicationDevice(device)
            } else {
                if (!audio.isBluetoothScoAvailableOffCall) return false
                audio.startBluetoothSco()
                audio.isBluetoothScoOn = true
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun releaseBluetoothMic() {
        if (!usingBluetoothMic) return
        usingBluetoothMic = false
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                audio.clearCommunicationDevice()
            } else {
                audio.isBluetoothScoOn = false
                audio.stopBluetoothSco()
            }
        } catch (e: Exception) {
            // ignora
        }
    }
}
