package com.exemplo.assistentevoz

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.view.KeyEvent

/**
 * Serviço que fica ativo em segundo plano e recebe o botão play/pause do fone.
 * Um aperto: começa a ouvir. Outro aperto (ouvindo ou falando): para.
 */
class VoiceButtonService : Service() {

    private lateinit var session: MediaSession
    private lateinit var listener: VoiceListener
    private var silentTrack: AudioTrack? = null

    override fun onCreate() {
        super.onCreate()
        Speaker.init(this)
        listener = VoiceListener(this, CommandHandler(this))
        goForeground()
        setupSession()
        startSilentAudio()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        listener.cancel()
        session.isActive = false
        session.release()
        silentTrack?.let {
            try {
                it.stop()
            } catch (e: Exception) {
                // ignora
            }
            it.release()
        }
        silentTrack = null
        super.onDestroy()
    }

    // ---------- Botão do fone ----------

    private fun setupSession() {
        session = MediaSession(this, "AssistenteVoz")
        session.setCallback(object : MediaSession.Callback() {
            @Suppress("DEPRECATION")
            override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                val event = mediaButtonIntent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                if (event != null) {
                    val isTrigger = when (event.keyCode) {
                        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                        KeyEvent.KEYCODE_MEDIA_PLAY,
                        KeyEvent.KEYCODE_MEDIA_PAUSE,
                        KeyEvent.KEYCODE_HEADSETHOOK -> true
                        else -> false
                    }
                    if (isTrigger) {
                        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) onHeadsetButton()
                        return true
                    }
                }
                return super.onMediaButtonEvent(mediaButtonIntent)
            }
        })
        session.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE
                )
                .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                .build()
        )
        session.isActive = true
    }

    private fun onHeadsetButton() {
        when {
            listener.listening -> listener.cancel()
            Speaker.isSpeaking() -> Speaker.stop()
            else -> listener.start(Prefs(this).bluetoothMic)
        }
    }

    /**
     * Toca um áudio totalmente silencioso em loop. Isso faz o Android tratar o app como
     * "reprodutor de mídia" e mandar o botão do fone para ele.
     */
    private fun startSilentAudio() {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(8000)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val bytes = 8000 * 2 // 1 segundo de silêncio
            val track = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bytes)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(ByteArray(bytes), 0, bytes)
            track.setLoopPoints(0, 8000, -1)
            track.play()
            silentTrack = track
        } catch (e: Exception) {
            // Sem o áudio silencioso o botão pode falhar em alguns aparelhos, mas o serviço segue.
        }
    }

    // ---------- Notificação fixa (o Android exige para serviço em segundo plano) ----------

    private fun goForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Assistente de Voz", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Assistente de Voz ativo")
            .setContentText("Aperte o botão play/pause do fone para falar")
            .setContentIntent(open)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 30) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        private const val CHANNEL_ID = "assistente_voz"
        private const val NOTIFICATION_ID = 1
    }
}
