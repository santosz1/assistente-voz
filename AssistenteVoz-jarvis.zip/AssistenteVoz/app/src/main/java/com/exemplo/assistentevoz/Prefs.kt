package com.exemplo.assistentevoz

import android.content.Context

/** Guarda as configurações simples do app. */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("assistente", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(value) = sp.edit().putString("apiKey", value).apply()

    var readNotifications: Boolean
        get() = sp.getBoolean("readNotifications", true)
        set(value) = sp.edit().putBoolean("readNotifications", value).apply()

    var headsetButton: Boolean
        get() = sp.getBoolean("headsetButton", false)
        set(value) = sp.edit().putBoolean("headsetButton", value).apply()

    var bluetoothMic: Boolean
        get() = sp.getBoolean("bluetoothMic", true)
        set(value) = sp.edit().putBoolean("bluetoothMic", value).apply()

    /** Voz grave e calma (pitch/velocidade ajustados) na voz nativa do Android. */
    var jarvisVoice: Boolean
        get() = sp.getBoolean("jarvisVoice", true)
        set(value) = sp.edit().putBoolean("jarvisVoice", value).apply()

    /** Nome técnico da voz nativa escolhida pelo usuário (vazio = automática). */
    var voiceName: String
        get() = sp.getString("voiceName", "") ?: ""
        set(value) = sp.edit().putString("voiceName", value).apply()

    /** Como o assistente trata você (ex.: "senhor", "senhora", seu nome). */
    var callName: String
        get() = sp.getString("callName", "senhor") ?: "senhor"
        set(value) = sp.edit().putString("callName", value).apply()

    /** Chave da ElevenLabs (opcional). Se vazia, usa a voz nativa. */
    var elevenKey: String
        get() = sp.getString("elevenKey", "") ?: ""
        set(value) = sp.edit().putString("elevenKey", value).apply()

    /** ID da voz escolhida na ElevenLabs (opcional). */
    var elevenVoiceId: String
        get() = sp.getString("elevenVoiceId", "") ?: ""
        set(value) = sp.edit().putString("elevenVoiceId", value).apply()
}
