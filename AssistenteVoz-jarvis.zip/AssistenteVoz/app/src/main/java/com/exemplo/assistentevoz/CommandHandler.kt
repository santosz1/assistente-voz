package com.exemplo.assistentevoz

import android.accessibilityservice.AccessibilityService
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import java.text.Normalizer
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Entende o que você falou e executa. Comandos locais funcionam sem internet;
 * o que não for reconhecido vai para a IA.
 */
class CommandHandler(private val ctx: Context) {

    private var torchOn = false

    fun handle(raw: String, reply: (String) -> Unit) {
        val t = normalize(raw)

        when {
            t.isBlank() -> reply("Não ouvi nada.")

            t == "parar" || t == "pare" || t == "silencio" -> Speaker.stop()

            t.contains("timer") || t.contains("temporizador") -> reply(startTimer(t))

            t.contains("que horas") || t.contains("qual a hora") || t.contains("qual e a hora") ||
                t.contains("me diga a hora") || t == "hora" -> reply(timeText())

            t.contains("que dia") || t.contains("data de hoje") || t.contains("dia da semana") ->
                reply(dateText())

            t.contains("bateria") -> reply(batteryText())

            t.contains("lanterna") -> reply(torch(!(t.contains("desliga") || t.contains("apaga"))))

            t.contains("volume") -> reply(volume(t))

            t.contains("voltar") || t == "volta" -> reply(globalAction(AccessibilityService.GLOBAL_ACTION_BACK))

            t.contains("tela inicial") || t.contains("pagina inicial") || t == "home" ->
                reply(globalAction(AccessibilityService.GLOBAL_ACTION_HOME))

            t.contains("recentes") -> reply(globalAction(AccessibilityService.GLOBAL_ACTION_RECENTS))

            t.contains("notificacoes") && (t.contains("abr") || t.contains("mostr")) ->
                reply(globalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS))

            Regex("^(abrir|abre|abra)\\s+(o |a |os |as )?(.+)$").containsMatchIn(t) -> {
                val name = Regex("^(abrir|abre|abra)\\s+(o |a |os |as )?(.+)$").find(t)!!.groupValues[3]
                reply(if (openApp(name)) "Abrindo $name." else "Não encontrei o aplicativo $name.")
            }

            t.startsWith("ligar") || t.startsWith("liga para") || t.startsWith("telefonar") -> reply(dial(t))

            else -> askAi(raw, reply)
        }
    }

    // ---------- Comandos ----------

    private fun timeText(): String {
        val now = LocalTime.now()
        val h = now.hour
        val m = now.minute
        val hTxt = when (h) {
            0 -> "meia-noite"
            1 -> "1 hora"
            12 -> "meio-dia"
            else -> "$h horas"
        }
        val verb = if (h == 0 || h == 1 || h == 12) "É" else "São"
        val mTxt = when (m) {
            0 -> ""
            1 -> " e 1 minuto"
            else -> " e $m minutos"
        }
        return "$verb $hTxt$mTxt."
    }

    private fun dateText(): String {
        val fmt = DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM 'de' yyyy", Locale("pt", "BR"))
        return "Hoje é " + LocalDate.now().format(fmt) + "."
    }

    private fun batteryText(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = if (bm.isCharging) ", carregando" else ""
        return "A bateria está em $pct por cento$charging."
    }

    private fun torch(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Este aparelho não tem lanterna."
            cm.setTorchMode(id, on)
            torchOn = on
            if (on) "Lanterna ligada." else "Lanterna desligada."
        } catch (e: Exception) {
            "Não consegui usar a lanterna."
        }
    }

    private fun volume(t: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val direction = when {
            t.contains("aument") || t.contains("sobe") || t.contains("mais alto") -> AudioManager.ADJUST_RAISE
            t.contains("diminu") || t.contains("abaix") || t.contains("desce") || t.contains("mais baixo") ->
                AudioManager.ADJUST_LOWER
            else -> return "Diga aumentar ou diminuir o volume."
        }
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        return "Pronto."
    }

    private fun globalAction(action: Int): String {
        val service = AssistantAccessibilityService.instance
            ?: return "Ative o Assistente de Voz nas configurações de acessibilidade para eu controlar o celular."
        service.performGlobalAction(action)
        return "Feito."
    }

    private fun openApp(name: String): Boolean {
        if (name.isBlank()) return false
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(intent, 0)
        val target = apps.firstOrNull { normalize(it.loadLabel(pm).toString()).contains(name.trim()) }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(target.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return true
    }

    private fun dial(t: String): String {
        val digits = t.filter { it.isDigit() }
        if (digits.length < 8) return "Por enquanto só consigo ligar para números. Diga ligar para e os dígitos."
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return "Abrindo o discador."
    }

    private fun startTimer(t: String): String {
        val m = Regex("(\\d+)\\s*(segundo|minuto|hora)").find(t)
            ?: return "Diga, por exemplo, timer de 5 minutos."
        val n = m.groupValues[1].toInt()
        val seconds = when (m.groupValues[2]) {
            "segundo" -> n
            "minuto" -> n * 60
            else -> n * 3600
        }
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            "Timer de $n ${m.groupValues[2]}${if (n == 1) "" else "s"} iniciado."
        } catch (e: ActivityNotFoundException) {
            "Não achei um app de relógio para criar o timer."
        }
    }

    private fun askAi(raw: String, reply: (String) -> Unit) {
        val prefs = Prefs(ctx)
        val key = prefs.apiKey
        if (key.isBlank()) {
            reply("Não entendi esse comando. Coloque a chave da IA no app para eu responder qualquer pergunta.")
        } else {
            ClaudeClient.ask(key, raw, prefs.callName, reply)
        }
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(Locale("pt", "BR")), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .trim()
}
