package com.exemplo.assistentevoz

import android.content.Context

/** Guarda as configurações simples do app. */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("assistente", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(value) = sp.edit().putString("apiKey", value).apply()

    var readNotifications: Boolean
        get() = sp.getBoolean("readNotifications", true)
        set(value) = sp.edit().putBoolean("readNotifications", value).apply()

    var headsetButton: Boolean
        get() = sp.getBoolean("headsetButton", false)
        set(value) = sp.edit().putBoolean("headsetButton", value).apply()

    var bluetoothMic: Boolean
        get() = sp.getBoolean("bluetoothMic", true)
        set(value) = sp.edit().putBoolean("bluetoothMic", value).apply()
}
