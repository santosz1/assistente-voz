package com.exemplo.assistentevoz

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** A "voz" do assistente (Text-to-Speech do Android, em português do Brasil). */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayDeque<String>()

    @Synchronized
    fun init(context: Context) {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("pt", "BR")
                synchronized(this) {
                    ready = true
                    while (pending.isNotEmpty()) {
                        say(pending.removeFirst())
                    }
                }
            }
        }
    }

    @Synchronized
    fun speak(text: String) {
        if (text.isBlank()) return
        if (!ready) {
            pending.addLast(text)
            return
        }
        say(text)
    }

    @Synchronized
    fun stop() {
        pending.clear()
        tts?.stop()
    }

    @Synchronized
    fun isSpeaking(): Boolean = tts?.isSpeaking == true

    private fun say(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, System.nanoTime().toString())
    }
}
