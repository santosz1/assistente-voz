package com.exemplo.assistentevoz

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var headsetSwitch: Switch
    private lateinit var prefs: Prefs
    private lateinit var commands: CommandHandler
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        commands = CommandHandler(this)
        Speaker.init(this)
        setContentView(buildUi())

        // Se o botão do fone estava ligado, religa o serviço ao abrir o app.
        if (prefs.headsetButton &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            startHeadsetService()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        root.addView(TextView(this).apply {
            text = "Assistente de Voz"
            textSize = 26f
        })

        status = TextView(this).apply {
            text = "Toque em Falar e diga um comando. Ex.: que horas são?"
            textSize = 18f
            setPadding(0, dp(16), 0, dp(16))
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "🎤  Falar"
            textSize = 22f
            setOnClickListener { startListening() }
        }, LinearLayout.LayoutParams(match, dp(90)))

        // ---- Botão do fone Bluetooth ----
        headsetSwitch = Switch(this).apply {
            text = "Ativar pelo botão play/pause do fone"
            isChecked = prefs.headsetButton
            setPadding(0, dp(24), 0, dp(8))
            setOnCheckedChangeListener { _, checked ->
                if (checked) {
                    enableHeadsetButton()
                } else {
                    prefs.headsetButton = false
                    stopService(Intent(this@MainActivity, VoiceButtonService::class.java))
                }
            }
        }
        root.addView(headsetSwitch, LinearLayout.LayoutParams(match, wrap))

        root.addView(Switch(this).apply {
            text = "Usar o microfone do fone (senão usa o do celular)"
            isChecked = prefs.bluetoothMic
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, checked ->
                prefs.bluetoothMic = checked
                if (checked && Build.VERSION.SDK_INT >= 31 &&
                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 3)
                }
            }
        }, LinearLayout.LayoutParams(match, wrap))

        root.addView(Switch(this).apply {
            text = "Ler notificações em voz alta"
            isChecked = prefs.readNotifications
            setOnCheckedChangeListener { _, checked -> prefs.readNotifications = checked }
            setPadding(0, dp(8), 0, dp(8))
        }, LinearLayout.LayoutParams(match, wrap))

        root.addView(Button(this).apply {
            text = "1) Liberar acesso às notificações"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })

        root.addView(Button(this).apply {
            text = "2) Liberar controle do celular (acessibilidade)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        val keyField = EditText(this).apply {
            hint = "Chave da API da Anthropic (para perguntas livres)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.apiKey)
        }
        root.addView(keyField, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(24) })

        root.addView(Button(this).apply {
            text = "Salvar chave"
            setOnClickListener {
                prefs.apiKey = keyField.text.toString().trim()
                Toast.makeText(this@MainActivity, "Chave salva", Toast.LENGTH_SHORT).show()
            }
        })

        return ScrollView(this).apply { addView(root) }
    }

    // ---------- Botão do fone ----------

    private fun enableHeadsetButton() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), 2)
            return
        }
        startHeadsetService()
    }

    private fun startHeadsetService() {
        prefs.headsetButton = true
        startForegroundService(Intent(this, VoiceButtonService::class.java))
    }

    // ---------- Botão "Falar" da tela ----------

    private fun show(text: String) {
        status.text = text
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            show("O reconhecimento de voz não está disponível neste aparelho.")
            return
        }
        Speaker.stop()
        recognizer?.destroy()

        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { show("Ouvindo...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { show("Não entendi. Toque em Falar e tente de novo.") }
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                show("Você: $text")
                commands.handle(text) { answer ->
                    show(answer)
                    Speaker.speak(answer)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
        }
        r.startListening(intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            1 -> if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
            2 -> {
                val micGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (micGranted) {
                    startHeadsetService()
                } else {
                    headsetSwitch.isChecked = false
                    Toast.makeText(this, "Sem o microfone não dá para usar o botão do fone.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }
}
