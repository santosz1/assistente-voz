package com.exemplo.assistentevoz

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Manda perguntas livres para a IA (API da Anthropic) e devolve a resposta. */
object ClaudeClient {
    private const val MODEL = "claude-haiku-4-5-20251001"
    private const val SYSTEM =
        "Você é um assistente de voz em um celular Android. Responda sempre em português do Brasil, " +
            "em no máximo duas frases curtas, sem markdown, sem listas e sem emojis, " +
            "porque sua resposta será lida em voz alta."

    fun ask(apiKey: String, question: String, onResult: (String) -> Unit) {
        Thread {
            val answer = try {
                call(apiKey, question)
            } catch (e: Exception) {
                "Não consegui falar com a IA. Verifique a internet e a chave."
            }
            Handler(Looper.getMainLooper()).post { onResult(answer) }
        }.start()
    }

    private fun call(apiKey: String, question: String): String {
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", apiKey)
        conn.setRequestProperty("anthropic-version", "2023-06-01")

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 300)
            .put("system", SYSTEM)
            .put(
                "messages",
                JSONArray().put(JSONObject().put("role", "user").put("content", question))
            )
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) return "A IA devolveu o erro $code. Confira a chave da API."

        val content = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") sb.append(block.getString("text"))
        }
        return sb.toString().trim().ifEmpty { "A IA não devolveu resposta." }
    }
}
