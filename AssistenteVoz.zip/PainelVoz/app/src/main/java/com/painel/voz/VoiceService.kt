package com.painel.voz

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/**
 * Fica escutando o microfone em segundo plano.
 *  - "olá abrir WhatsApp"  -> executa na hora
 *  - "olá" (sozinho)       -> toca um bipe e o PRÓXIMO trecho falado vira o comando
 *
 * Enquanto o painel está aberto o serviço se pausa (só um reconhecedor pode usar o microfone).
 */
class VoiceService : Service() {

    companion object {
        const val ACTION_STOP = "com.painel.voz.STOP_WAKE"
        private const val CHANNEL = "wake"
        private const val NOTIF_ID = 42
        private const val ARM_MS = 8000L

        // "olá" no começo da frase (com ou sem acento), seguido de espaço/pontuação/fim.
        private val WAKE = Regex("^\\s*[oO][lL][aAáÁàÀâÂãÃ](?=[\\s,.!?;:\\-]|$)[\\s,.!?;:\\-]*")

        @Volatile var instance: VoiceService? = null
        @Volatile var micPaused = false
        val running: Boolean get() = instance != null

        fun start(ctx: Context) { ctx.startForegroundService(Intent(ctx, VoiceService::class.java)) }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, VoiceService::class.java)) }

        /** Chamado pela Activity: true enquanto o painel está visível. */
        fun setPaused(p: Boolean) {
            micPaused = p
            instance?.let { s -> s.main.post { s.applyPause() } }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var armedUntil = 0L
    private var failures = 0
    private var overlay: View? = null
    private val kick = Runnable { startListening() }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun disablePref() {
        getSharedPreferences("painel", MODE_PRIVATE).edit().putBoolean("wake", false).apply()
    }

    override fun onCreate() {
        super.onCreate()
        TtsHelper.init(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Escuta por voz", NotificationManager.IMPORTANCE_LOW))
        if (!goForeground("Diga “olá” e depois o comando.")) { stopSelf(); return }
        instance = this
        addOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            disablePref()
            stopSelf()
            return START_NOT_STICKY
        }
        if (instance === this) {
            goForeground("Diga “olá” e depois o comando.")
            if (!micPaused) listenSoon(0)
        }
        // Não reiniciar sozinho: no Android 14+ um serviço de microfone só pode
        // ser iniciado com o app visível.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        removeOverlay()
        if (instance === this) instance = null
        super.onDestroy()
    }

    /* ---------- Notificação fixa (exigida para serviços em primeiro plano) ---------- */

    private fun notif(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Painel Voz")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Desativar", stop)
            .build()
    }

    private fun goForeground(text: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= 30)
            startForeground(NOTIF_ID, notif(text), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIF_ID, notif(text))
        true
    } catch (e: Exception) { false }

    private fun report(msg: String, speak: Boolean = false) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notif(msg))
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        if (speak) TtsHelper.speak(msg)
    }

    /* ---------- Reconhecimento contínuo ---------- */

    private fun listenSoon(delay: Long) {
        main.removeCallbacks(kick)
        main.postDelayed(kick, delay)
    }

    private fun applyPause() {
        if (micPaused) {
            main.removeCallbacks(kick)
            recognizer?.destroy(); recognizer = null   // libera o microfone para o painel
        } else if (instance === this) {
            listenSoon(500)
        }
    }

    private fun startListening() {
        if (micPaused || instance !== this) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            report("Permissão do microfone removida. Escuta desativada."); disablePref(); stopSelf(); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            report("Reconhecimento de voz indisponível neste aparelho."); disablePref(); stopSelf(); return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)   // economiza dados/bateria quando possível
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        recognizer?.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: Bundle?) {
            failures = 0
            val heard = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            if (heard.isNotEmpty()) onHeard(heard)
            listenSoon(300)
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    report("Permissão do microfone negada. Escuta desativada."); disablePref(); stopSelf()
                }
                // Silêncio é o caso normal: só reinicia.
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> listenSoon(300)
                // Ocupado, rede, cliente etc.: recria o reconhecedor e espera cada vez mais (máx. 16 s).
                else -> {
                    recognizer?.destroy(); recognizer = null
                    failures = minOf(failures + 1, 4)
                    listenSoon(1000L shl failures)
                }
            }
        }

        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(r: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    /* ---------- Palavra de ativação e execução ---------- */

    private fun afterWake(raw: String): String? = WAKE.find(raw)?.let { raw.substring(it.value.length).trim() }

    private fun onHeard(results: List<String>) {
        // Já ouvi "olá" sozinho: o que veio agora é o comando.
        if (SystemClock.elapsedRealtime() < armedUntil) {
            armedUntil = 0
            val raw = results.first()
            val cmd = (afterWake(raw) ?: raw).trim()
            if (cmd.isNotEmpty()) execute(cmd)
            return
        }
        // Qualquer uma das hipóteses do reconhecedor pode conter o "olá".
        val rest = results.firstNotNullOfOrNull { afterWake(it) } ?: return
        if (rest.isEmpty()) {
            armedUntil = SystemClock.elapsedRealtime() + ARM_MS
            beep()
            report("Estou ouvindo… diga o comando.", speak = true)
        } else execute(rest)
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            main.postDelayed({ tg.release() }, 400)
        } catch (e: Exception) { }
    }

    private fun execute(cmd: String) {
        val msg = Actions.voice(this, cmd)
        if (msg != null) { report(msg, speak = true); return }
        // Comando que depende da tela (cadastrar, buscar, notificações...): abre o painel.
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(MainActivity.EXTRA_CMD, cmd))
        } catch (e: Exception) {
            report("Não consegui abrir o painel. Libere \"Exibir sobre outros apps\".", speak = true)
        }
    }

    /* ---------- Janela invisível 1x1 ----------
     * Com a permissão "Exibir sobre outros apps" o Android deixa um serviço abrir telas
     * (apps, discador, painel) mesmo em segundo plano. Uma janela de sobreposição visível
     * mantém essa isenção válida nas versões mais novas do Android. */

    private fun addOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
            getSystemService(WindowManager::class.java).addView(v, lp)
            overlay = v
        } catch (e: Exception) { }
    }

    private fun removeOverlay() {
        overlay?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (e: Exception) { } }
        overlay = null
    }
}
