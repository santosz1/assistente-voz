package com.painel.voz

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Fala de saída do painel (TTS). Tenta escolher uma voz masculina em pt-BR;
 * se o aparelho não tiver nenhuma, usa a voz padrão do idioma.
 */
object TtsHelper {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.language = Locale("pt", "BR")
                pickMaleVoice()
                pending?.let { speak(it); pending = null }
            }
        }
    }

    private fun pickMaleVoice() {
        val engine = tts ?: return
        try {
            val voices: Set<Voice> = engine.voices ?: return
            val male = voices.filter {
                it.locale.language == "pt" &&
                    !it.isNetworkConnectionRequired &&
                    it.name.contains("male", ignoreCase = true) &&
                    !it.name.contains("female", ignoreCase = true)
            }.minByOrNull { it.name.length }
                ?: voices.firstOrNull {
                    it.locale.language == "pt" && !it.name.contains("female", ignoreCase = true) &&
                        (it.name.contains("#male", true) || it.name.endsWith("-local") || it.name.contains("m0", true))
                }
            if (male != null) engine.voice = male
            else engine.setPitch(0.82f)   // sem voz masculina instalada: baixa o tom da voz padrão
        } catch (e: Exception) { }
    }

    fun speak(text: String) {
        val engine = tts
        if (engine == null || !ready) { pending = text; return }
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "painel-voz")
    }

    fun stop() { tts?.stop() }

    fun shutdown() {
        tts?.shutdown()
        tts = null
        ready = false
    }
}
