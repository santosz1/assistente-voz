package com.painel.voz

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    companion object {
        /** Comando falado que o VoiceService entrega ao painel (cadastrar, buscar, notificações...). */
        const val EXTRA_CMD = "voice_cmd"
        private const val REQ_MIC = 1
        private const val REQ_WAKE = 2
        private const val REQ_ONBOARD = 3
    }

    private lateinit var web: WebView
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var wanted = false

    private var pageReady = false
    private var pendingCmd: String? = null
    private var overlayAsked = false
    private var notifAsked = false
    private var wakeFlow = false
    private var onboarding = false
    private val prefs by lazy { getSharedPreferences("painel", MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        TtsHelper.init(this)
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    pageReady = true
                    syncWakeUi()
                    syncPermUi()
                    pendingCmd?.let { c -> pendingCmd = null; js("appHeard(${q(c)}, true)") }
                }
            }
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        deliverCommand(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        deliverCommand(intent)
    }

    override fun onResume() {
        super.onResume()
        // Painel visível: o serviço de escuta se pausa para liberar o microfone.
        VoiceService.setPaused(true)
        syncWakeUi()
        syncPermUi()
        if (onboarding) { onboarding = false; continueOnboarding() }
        else if (wakeFlow) { wakeFlow = false; startWake(silent = false) }     // voltou da tela de permissão
        else if (prefs.getBoolean("wake", false) && !VoiceService.running) startWake(silent = true)
    }

    override fun onPause() {
        if (wanted) stopMic()                 // o microfone do painel não vale em segundo plano
        VoiceService.setPaused(false)         // e o serviço volta a escutar "olá"
        super.onPause()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        // TTS não é encerrado aqui: o VoiceService pode continuar falando em segundo plano.
        super.onDestroy()
    }

    private fun js(code: String) { main.post { web.evaluateJavascript(code, null) } }
    private fun q(s: String) = JSONObject.quote(s)

    private fun deliverCommand(i: Intent?) {
        val c = i?.getStringExtra(EXTRA_CMD) ?: return
        i?.removeExtra(EXTRA_CMD)
        if (pageReady) js("appHeard(${q(c)}, true)") else pendingCmd = c
    }

    /* ---------- Escuta por "olá" em segundo plano ---------- */

    private fun syncWakeUi() {
        if (pageReady) js("if(window.appWake)appWake(${prefs.getBoolean("wake", false)})")
    }

    private fun startWake(silent: Boolean) {
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (silent) {                          // religar sozinho ao abrir o app: sem perguntar nada
            if (micOk && !VoiceService.running) VoiceService.start(this)
            return
        }
        val ask = ArrayList<String>()
        if (!micOk) ask += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !notifAsked &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifAsked = true; ask += Manifest.permission.POST_NOTIFICATIONS
        }
        if (ask.isNotEmpty()) { requestPermissions(ask.toTypedArray(), REQ_WAKE); return }

        if (!Settings.canDrawOverlays(this) && !overlayAsked) {
            overlayAsked = true; wakeFlow = true
            js("appInfo('Libere \"Exibir sobre outros apps\" para o Painel Voz e volte. Isso permite abrir apps por voz.')")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        prefs.edit().putBoolean("wake", true).apply()
        if (!VoiceService.running) VoiceService.start(this)
        js("appWake(true)")
        js("appInfo('Escuta ativa. Saia do painel e diga \"olá\" seguido do comando.')")
    }

    /* ---------- Fluxo guiado de permissões ----------
     * Pede, uma de cada vez, cada permissão com o diálogo padrão do Android.
     * Nenhuma permissão é concedida sozinha: o sistema sempre pergunta ao usuário. */

    private fun permGranted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun notifListenerOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        return enabled.contains(packageName)
    }

    private fun permStatusJson(): String {
        val o = JSONObject()
        o.put("microfone", permGranted(Manifest.permission.RECORD_AUDIO))
        o.put("notificacoesApp",
            if (Build.VERSION.SDK_INT >= 33) permGranted(Manifest.permission.POST_NOTIFICATIONS) else true)
        o.put("sobreposicao", Settings.canDrawOverlays(this))
        o.put("lerNotificacoes", notifListenerOn())
        return o.toString()
    }

    private fun syncPermUi() {
        if (pageReady) js("if(window.appPerms)appPerms(" + permStatusJson() + ")")
    }

    private fun startOnboarding() { onboarding = true; continueOnboarding() }

    /** Avança para a próxima permissão pendente; para quando não falta nenhuma. */
    private fun continueOnboarding() {
        val runtime = ArrayList<String>()
        if (!permGranted(Manifest.permission.RECORD_AUDIO)) runtime += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !permGranted(Manifest.permission.POST_NOTIFICATIONS))
            runtime += Manifest.permission.POST_NOTIFICATIONS
        if (runtime.isNotEmpty()) { requestPermissions(runtime.toTypedArray(), REQ_ONBOARD); return }

        if (!Settings.canDrawOverlays(this)) {
            onboarding = true
            js("appInfo('Libere \"Exibir sobre outros apps\" e volte para continuar.')")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!notifListenerOn()) {
            onboarding = true
            js("appInfo('Ative o Painel Voz na lista de acesso a notificações e volte.')")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return
        }
        syncPermUi()
        js("appInfo('Todas as permissões foram concedidas.')")
    }

    private fun stopWake() {
        prefs.edit().putBoolean("wake", false).apply()
        VoiceService.stop(this)
        js("appWake(false)")
        js("appInfo('Escuta em segundo plano desativada.')")
    }

    /* ---------- Voz do painel (reconhecimento nativo, sem resposta falada) ---------- */
    private fun startMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("appError('Reconhecimento de voz indisponível neste aparelho.')"); return
        }
        wanted = true
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        }
        js("appMic(true)")
        listen()
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        recognizer?.startListening(i)
    }

    private fun stopMic() { wanted = false; recognizer?.cancel(); js("appMic(false)") }
    private fun again(delay: Long) { if (wanted) main.postDelayed({ if (wanted) listen() }, delay) }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        when (code) {
            REQ_WAKE -> if (micOk) startWake(silent = false) else js("appError('Permissão do microfone negada.')")
            REQ_ONBOARD -> { syncPermUi(); continueOnboarding() }
            else -> if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) startMic()
                    else js("appError('Permissão do microfone negada.')")
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: Bundle?) {
            r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                ?.let { js("appHeard(${q(it)}, true)") }
            again(250)
        }
        override fun onPartialResults(r: Bundle?) {
            r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                ?.let { js("appHeard(${q(it)}, false)") }
        }
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                wanted = false; js("appMic(false)"); js("appError('Permissão do microfone negada.')")
            } else again(600)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    /* ---------- Ponte JavaScript <-> Android ---------- */
    inner class Bridge {
        @JavascriptInterface fun toggleMic() { main.post { if (wanted) stopMic() else startMic() } }

        @JavascriptInterface fun toggleWake() {
            main.post { if (prefs.getBoolean("wake", false)) stopWake() else startWake(silent = false) }
        }

        @JavascriptInterface fun notifs(): String = JSONArray(NotifService.recent()).toString()

        @JavascriptInterface fun run(cmd: String, arg: String): String = Actions.run(this@MainActivity, cmd, arg)

        /** Status atual de cada permissão, para a tela mostrar o que falta liberar. */
        @JavascriptInterface fun permStatus(): String = permStatusJson()

        /** Inicia o fluxo guiado: pede as permissões que faltam, uma por vez, pelos diálogos do sistema. */
        @JavascriptInterface fun pedirPermissoes() { main.post { startOnboarding() } }

        /** Fala um texto em voz alta (voz masculina configurada no TtsHelper). */
        @JavascriptInterface fun falar(texto: String) { TtsHelper.speak(texto) }
    }
}
