package com.painel.voz

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.text.Normalizer

/**
 * Ações do aparelho usadas tanto pela ponte do WebView (MainActivity)
 * quanto pelo serviço de escuta em segundo plano (VoiceService).
 */
object Actions {
    private val main = Handler(Looper.getMainLooper())

    fun norm(s: String) =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").trim()

    private fun clean(s: String) = s.replace(Regex("[.,;!?]+$"), "").trim()

    /** Abre uma tela. Fora de uma Activity (serviço) precisa da flag NEW_TASK. */
    private fun startAct(ctx: Context, i: Intent) {
        if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        main.post { try { ctx.startActivity(i) } catch (e: Exception) { } }
    }

    fun run(ctx: Context, cmd: String, arg: String): String = when (cmd) {
        "app" -> {
            val pm = ctx.packageManager
            val want = norm(arg)
            val apps = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == want }
                ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(want) }
            val li = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (hit == null || li == null) "Não encontrei o app \"$arg\"."
            else { startAct(ctx, li); "Abrindo ${hit.loadLabel(pm)}." }
        }
        "wifi" -> {
            startAct(ctx, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            "Abrindo o painel de Wi-Fi."
        }
        "lanterna" -> try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.first {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            cm.setTorchMode(id, arg == "on")
            if (arg == "on") "Lanterna ligada." else "Lanterna desligada."
        } catch (e: Exception) { "Não consegui acessar a lanterna." }
        "volume" -> {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (arg == "up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI)
            "Volume ajustado."
        }
        "discar" -> {
            startAct(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$arg")))
            "Abrindo o discador para $arg."
        }
        "permitir_notificacoes" -> {
            startAct(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            "Ative o acesso a notificações para o Painel Voz."
        }
        "limpar_notificacoes" -> { NotifService.clearAll(); "Notificações limpas." }
        else -> "Comando desconhecido."
    }

    /* ---------- Interpretação de voz (espelha o nativeCommand() do index.html) ---------- */

    // Comandos que só o painel (WebView) sabe executar: usam o banco de dados da tela.
    private val DATA = Regex(
        "^(cadastrar|adicionar|novo|nova|criar|salvar|limpar busca|limpar pesquisa|mostrar tudo|" +
        "mostrar todos|ver tudo|buscar|pesquisar|procurar|encontrar|excluir|apagar|deletar|remover)\\b")
    private val FIELDS = Regex("\\b(titulo|categoria|conteudo)\\b")
    private val WIFI = Regex("^(abrir |ligar |desligar |ativar )?wi[- ]?fi\\b")
    private val TORCH_OFF = Regex("^(desligar|apagar|desativar)")
    private val VOLUME = Regex("\\bvolume\\b")
    private val VOL_DOWN = Regex("(diminu|baix|menos)")
    private val VOL_UP = Regex("(aument|sub|mais|alto)")
    private val OPEN = Regex("^(abrir|abra|iniciar)\\s+\\S")
    private val DIAL = Regex("^(ligar para|ligar|discar|chamar)\\b")

    /**
     * Executa um comando falado sem abrir o painel.
     * Devolve a mensagem de resultado, ou null quando o comando precisa do painel.
     */
    fun voice(ctx: Context, text: String): String? {
        val t = clean(text)
        val n = norm(t)
        if (DATA.containsMatchIn(n)) return null
        return when {
            WIFI.containsMatchIn(n) -> run(ctx, "wifi", "")
            "lanterna" in n -> run(ctx, "lanterna", if (TORCH_OFF.containsMatchIn(n)) "off" else "on")
            VOLUME.containsMatchIn(n) -> when {
                VOL_DOWN.containsMatchIn(n) -> run(ctx, "volume", "down")
                VOL_UP.containsMatchIn(n) -> run(ctx, "volume", "up")
                else -> "Diga \"aumentar volume\" ou \"diminuir volume\"."
            }
            "notifica" in n -> null
            OPEN.containsMatchIn(n) -> run(ctx, "app", clean(t.replace(Regex("^\\S+\\s+"), "")))
            DIAL.containsMatchIn(n) -> {
                val num = t.replace(Regex("\\D"), "")
                if (num.length >= 8) run(ctx, "discar", num)
                else "Diga o número completo. Ex.: \"discar 11 99999 8888\"."
            }
            FIELDS.containsMatchIn(n) -> null
            else -> "Não entendi: \"$t\"."
        }
    }
}
